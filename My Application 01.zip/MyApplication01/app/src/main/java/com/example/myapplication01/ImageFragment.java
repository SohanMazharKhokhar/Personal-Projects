package com.example.myapplication01;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
public class ImageFragment extends Fragment {
    private ImageView mainImageView;
    private final int[] imageResIds = {
            R.drawable.image1, R.drawable.image2, R.drawable.image3
    };
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_image, container, false);

        mainImageView = view.findViewById(R.id.main_image);
        int[] Imag_ids = { R.id.Image1, R.id.Image2, R.id.Image3 };
        for (int i = 0; i < Imag_ids.length; i++) {
            ImageView thumb = view.findViewById(Imag_ids[i]);
            int imageRes = imageResIds[i];
            thumb.setImageResource(imageRes);
            final int selectedImageRes = imageRes;
            thumb.setOnClickListener(v -> mainImageView.setImageResource(selectedImageRes));
        }
        mainImageView.setImageResource(imageResIds[0]);
        return view;
    }
}
